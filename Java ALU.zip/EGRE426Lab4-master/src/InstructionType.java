public enum InstructionType {
    R, I, J
}