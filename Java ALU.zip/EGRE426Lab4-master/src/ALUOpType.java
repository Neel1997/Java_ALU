public enum ALUOpType {
    ADD,
    SUBTRACT,
    AND,
    OR,
    XOR,
    SLL,
    SRL,
    SLA,
    SRA
}
